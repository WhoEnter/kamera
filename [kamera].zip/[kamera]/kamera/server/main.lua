ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


ESX.RegisterUsableItem("fotograf", function(source, item)
    local xPlayer = ESX.GetPlayerFromId(source)
    TriggerClientEvent('usephoto', source, item)
end)


ESX.RegisterUsableItem("kamera", function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    TriggerClientEvent('kamerakullan', source)
end)


RegisterServerEvent('savecam')
AddEventHandler('savecam', function(photo)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local info = {}
    if xPlayer.getQuantity('bosfilm') >= 1  then
        info.photo = photo
        xPlayer.removeInventoryItem('bosfilm', 1)
        xPlayer.addInventoryItem('fotograf', 1, nil, info)
        TriggerClientEvent('inventory:client:ItemBox', src, ESX.GetItems()['fotograf'], "add")
        TriggerClientEvent('esx:showNotification', source, 'Fotoğraf Çekildi!')
    else
        TriggerClientEvent('esx:showNotification', source, 'Boş Fotoğraf Filmin Yok!')
end
end)


