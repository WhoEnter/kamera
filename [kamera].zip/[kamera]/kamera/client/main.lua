Keys = {
    ['ESC'] = 322, ['F1'] = 288, ['F2'] = 289, ['F3'] = 170, ['F5'] = 166, ['F6'] = 167, ['F7'] = 168, ['F8'] = 169, ['F9'] = 56, ['F10'] = 57,
    ['~'] = 243, ['1'] = 157, ['2'] = 158, ['3'] = 160, ['4'] = 164, ['5'] = 165, ['6'] = 159, ['7'] = 161, ['8'] = 162, ['9'] = 163, ['-'] = 84, ['='] = 83, ['BACKSPACE'] = 177,
    ['TAB'] = 37, ['Q'] = 44, ['W'] = 32, ['E'] = 38, ['R'] = 45, ['T'] = 245, ['Y'] = 246, ['U'] = 303, ['P'] = 199, ['['] = 39, [']'] = 40, ['ENTER'] = 18,
    ['CAPS'] = 137, ['A'] = 34, ['S'] = 8, ['D'] = 9, ['F'] = 23, ['G'] = 47, ['H'] = 74, ['K'] = 311, ['L'] = 182,
    ['LEFTSHIFT'] = 21, ['Z'] = 20, ['X'] = 73, ['C'] = 26, ['V'] = 0, ['B'] = 29, ['N'] = 249, ['M'] = 244, [','] = 82, ['.'] = 81,
    ['LEFTCTRL'] = 36, ['LEFTALT'] = 19, ['SPACE'] = 22, ['RIGHTCTRL'] = 70,
    ['HOME'] = 213, ['PAGEUP'] = 10, ['PAGEDOWN'] = 11, ['DELETE'] = 178,
    ['LEFT'] = 174, ['RIGHT'] = 175, ['TOP'] = 27, ['DOWN'] = 173,
}

ESX = nil

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(30)-- Saniye Bekletme
  end
end)

RegisterNetEvent('usephoto')
AddEventHandler('usephoto', function(ItemData)
    local ped = GetPlayerPed(-1)
    local photourl = ItemData.info.photo ~= nil and ItemData.info.photo or false
    SendNUIMessage({
        action = "open",
        url = photourl
    })
    SetNuiFocus(true, false)
end)

RegisterNetEvent('kamerakullan')
AddEventHandler('kamerakullan', function()
    CreateMobilePhone(1)
  CellCamActivate(true, true)
  Citizen.Wait(0)
  if hasFocus == true then
    SetNuiFocus(false, false)
    hasFocus = false
  end
    while true do
    Citizen.Wait(0)

    if IsControlJustPressed(1, 27) then -- Toogle Mode
        frontCam = not frontCam
        CellFrontCamActivate(frontCam)
    elseif IsControlJustPressed(1, 177) then -- CANCEL
      CellCamActivate(false, false)
      DestroyMobilePhone()
      break
    elseif IsControlJustPressed(1, 176) then -- TAKE.. PIC
        CellCamActivate(false, false)
        DestroyMobilePhone()
      exports['screenshot-basic']:requestScreenshotUpload("https://discord.com/api/webhooks/939177950220283936/bAwBxrahzsj4flfxprbi-2WA8FvWawoFpxeZbdVy3ssjSVelU56rgOPZw5E3GzudgDjw","files[]", function(data)
        local resp = json.decode(data)
        TriggerServerEvent('savecam', resp.attachments[1].proxy_url)
        print('link', resp.attachments[1].proxy_url )
      end)
        end
        HideHudComponentThisFrame(7)
        HideHudComponentThisFrame(8)
        HideHudComponentThisFrame(9)
        HideHudComponentThisFrame(6)
        HideHudComponentThisFrame(19)
       HideHudAndRadarThisFrame()
  end
  Citizen.Wait(1000)
end)


RegisterCommand('kamerafix', function()
    CellCamActivate(false, false)
    SetNuiFocus(false, false)
    print('kullandı')
    DestroyMobilePhone()
end)


RegisterNUICallback('CloseDocument', function()
    SetNuiFocus(false, false)
end)


